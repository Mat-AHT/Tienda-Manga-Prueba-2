package TiendaManga.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import TiendaManga.Model.Genero;
import jakarta.transaction.Transactional;
import TiendaManga.Repository.GeneroRepository;

@Service
@Transactional
public class GeneroService {

    @Autowired
    private GeneroRepository generoRepository;

    public List<Genero> listarGeneros(){
        return generoRepository.findAll();
    }

    public Genero buscarGenero(Integer id_genero){
        return generoRepository.findById(id_genero).orElseThrow(() -> new RuntimeException("El genero no existe en los registros"));
    }
    
    public Genero guardarGenero(Genero genero){
        return generoRepository.save(genero);
    }

    public Genero editarGenero(Integer id_genero, Genero genero){
        Genero genero1 = generoRepository.findById(id_genero).orElseThrow(() -> new RuntimeException("No se ha encontrado el genero."));
        if(genero.getNombreGenero() != null){
            genero1.setNombreGenero(genero.getNombreGenero());
        }
        if(genero.getMangas() != null){
            genero1.setMangas(genero.getMangas());
        }
        return generoRepository.save(genero);
    }

    public String eliminarGenero(Integer id_genero){
        try{
            Genero genero = generoRepository.findById(id_genero).orElseThrow(() -> new RuntimeException("No se ha encontrado el Genero con el ID " + id_genero));
            generoRepository.delete(genero);
            return "El genero ha sido eliminado";
        }catch(RuntimeException e){
            return e.getMessage();
        }
    }



}
